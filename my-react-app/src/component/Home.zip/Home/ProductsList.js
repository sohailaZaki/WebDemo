import { useEffect, useState } from 'react';
import line from '../../images/line.png';
import Product from './Product';

function ProductsList() {
   const apiurl = "https://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline";
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch(apiurl)
      .then((res) => res.json())
      .then((data) => {
        setProducts(data);
      });
  }, []);

  return (    
    <>
      <div className='d-flex flex-wrap justify-content-between align-items-center my-5 py-lg-5'>
        <img src={line} alt="line" />        
        <h2 className='text-center p-3' style={{ color: '#d27f96' }}>NEW ARRIVALS</h2>
        <img src={line} alt="line" />        
      </div>
      <div className='row'>
        {products.map((product) => (
          <div className='col-3' key={product.id}>
            <Product product={product} />
          </div>
        ))}
      </div>
    </>
  );
}

export default ProductsList;
